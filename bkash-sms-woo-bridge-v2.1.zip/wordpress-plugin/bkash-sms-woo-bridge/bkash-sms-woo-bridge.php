<?php
/**
 * Plugin Name: bKash SMS → WooCommerce Bridge
 * Description: Receives authenticated bKash merchant SMS notifications and conservatively matches recent WooCommerce orders.
 * Version: 2.1.0
 */
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    add_submenu_page(
        'woocommerce',
        'bKash SMS Bridge',
        'bKash SMS Bridge',
        'manage_woocommerce',
        'bkash-sms-bridge',
        'bkash_sms_bridge_settings_page'
    );
});

function bkash_sms_bridge_settings_page() {
    if (!current_user_can('manage_woocommerce')) return;
    if (isset($_POST['bkash_bridge_save'])) {
        check_admin_referer('bkash_bridge_settings');
        update_option('bkash_sms_bridge_settings', [
            'token' => sanitize_text_field(wp_unslash($_POST['token'] ?? '')),
        ]);
        echo '<div class="notice notice-success"><p>Saved.</p></div>';
    }
    $s = get_option('bkash_sms_bridge_settings', []);
    $token = isset($s['token']) ? $s['token'] : '';
    $endpoint = esc_url(rest_url('bkash-bridge/v1/sms'));
    ?>
    <div class="wrap">
        <h1>bKash SMS Bridge</h1>
        <form method="post">
            <?php wp_nonce_field('bkash_bridge_settings'); ?>
            <table class="form-table">
                <tr>
                    <th><label for="token">Shared secret token</label></th>
                    <td><input name="token" id="token" type="password" class="regular-text" value="<?php echo esc_attr($token); ?>" autocomplete="new-password"></td>
                </tr>
            </table>
            <p><strong>Android endpoint:</strong> <code><?php echo $endpoint; ?></code></p>
            <p><strong>Important:</strong> use a long random token and HTTPS. The Android app sends only matching payment SMS fields. It does not handle bKash PINs or OTPs.</p>
            <p><button class="button button-primary" name="bkash_bridge_save" value="1">Save settings</button></p>
        </form>
    </div>
    <?php
}

add_action('woocommerce_after_order_notes', function ($checkout) {
    echo '<div id="bkash_payer_fields"><h3>bKash payment</h3>';
    woocommerce_form_field('bkash_payer_number', [
        'type' => 'text',
        'label' => 'bKash number used for payment',
        'placeholder' => '01XXXXXXXXX',
        'required' => false,
        'description' => 'Optional, but helps the SMS bridge match the correct order when several orders have the same amount.'
    ], $checkout->get_value('bkash_payer_number'));
    echo '</div>';
});

add_action('woocommerce_checkout_create_order', function ($order, $data) {
    if (isset($_POST['bkash_payer_number'])) {
        $order->update_meta_data('_bkash_payer_number', sanitize_text_field(wp_unslash($_POST['bkash_payer_number'])));
    }
}, 10, 2);

add_action('rest_api_init', function () {
    register_rest_route('bkash-bridge/v1', '/sms', [
        'methods' => 'POST',
        'callback' => 'bkash_sms_bridge_receive',
        'permission_callback' => '__return_true',
    ]);
});

function bkash_sms_bridge_receive(WP_REST_Request $request) {
    if (!function_exists('wc_get_orders')) {
        return new WP_Error('woocommerce_missing', 'WooCommerce is required', ['status' => 500]);
    }

    $settings = get_option('bkash_sms_bridge_settings', []);
    $expected = isset($settings['token']) ? trim($settings['token']) : '';
    $auth = $request->get_header('authorization');

    if (!$expected || !preg_match('/^Bearer\s+(.+)$/i', $auth, $m) || !hash_equals($expected, trim($m[1]))) {
        return new WP_Error('forbidden', 'Invalid bridge token', ['status' => 403]);
    }

    $data = $request->get_json_params();
    $amount = isset($data['amount']) ? wc_format_decimal($data['amount']) : '';
    $trx = isset($data['trx_id']) ? sanitize_text_field($data['trx_id']) : '';
    $sender = isset($data['sender']) ? sanitize_text_field($data['sender']) : '';

    if (!$amount || !$trx) {
        return new WP_Error('bad_request', 'amount and trx_id are required', ['status' => 400]);
    }

    $key = 'bkash_trx_' . md5(strtolower($trx));
    if (get_transient($key)) {
        return ['ok' => true, 'status' => 'duplicate', 'trx_id' => $trx];
    }

    $orders = wc_get_orders([
        'status' => ['pending', 'on-hold'],
        'limit' => 30,
        'orderby' => 'date',
        'order' => 'DESC',
        'date_created' => '>' . (time() - 3600),
        'return' => 'objects',
    ]);

    $matches = [];
    foreach ($orders as $order) {
        if ((float)$order->get_total() !== (float)$amount) continue;

        $saved_sender = $order->get_meta('_bkash_payer_number');
        if ($saved_sender && $sender) {
            $a = preg_replace('/\D+/', '', $saved_sender);
            $b = preg_replace('/\D+/', '', $sender);
            if ($a && $b && substr($a, -10) !== substr($b, -10)) continue;
        }
        $matches[] = $order;
    }

    if (count($matches) !== 1) {
        return new WP_Error(
            'ambiguous_match',
            count($matches) ? 'More than one matching pending order exists' : 'No unique matching order',
            ['status' => 409]
        );
    }

    $order = $matches[0];
    $order->update_meta_data('_bkash_trx_id', $trx);
    $order->update_meta_data('_bkash_sms_sender', $sender);
    $order->add_order_note('Automatically matched bKash payment SMS. TrxID: ' . $trx);
    $order->payment_complete($trx);
    $order->save();

    set_transient($key, 1, 7 * DAY_IN_SECONDS);

    return ['ok' => true, 'status' => 'matched', 'order_id' => $order->get_id(), 'trx_id' => $trx];
}
