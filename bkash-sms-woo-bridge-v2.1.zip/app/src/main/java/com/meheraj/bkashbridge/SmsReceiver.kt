package com.meheraj.bkashbridge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.Executors

class SmsReceiver : BroadcastReceiver() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return

        val prefs = context.getSharedPreferences("bridge", Context.MODE_PRIVATE)
        val endpoint = prefs.getString("endpoint", "")?.trim().orEmpty()
        val token = prefs.getString("token", "")?.trim().orEmpty()
        if (endpoint.isBlank() || token.isBlank()) return

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        val body = messages.joinToString("") { it.messageBody ?: "" }
        val sender = messages.firstOrNull()?.originatingAddress.orEmpty()

        if (!body.contains("received payment", ignoreCase = true)) return
        if (body.contains("OTP", ignoreCase = true)) return

        val amount = Regex("""Tk\s*([0-9]+(?:\.[0-9]{1,2})?)""", RegexOption.IGNORE_CASE)
            .find(body)?.groupValues?.getOrNull(1)
        val trxId = Regex("""TrxID\s*([A-Za-z0-9]+)""", RegexOption.IGNORE_CASE)
            .find(body)?.groupValues?.getOrNull(1)

        if (amount.isNullOrBlank() || trxId.isNullOrBlank()) return

        val json = JSONObject()
            .put("amount", amount)
            .put("trx_id", trxId)
            .put("sender", sender)
            .put("message", body)
            .put("received_at", System.currentTimeMillis())

        val pending = goAsync()
        executor.execute {
            try {
                val request = Request.Builder()
                    .url(endpoint)
                    .header("Authorization", "Bearer $token")
                    .header("Content-Type", "application/json")
                    .post(json.toString().toRequestBody("application/json".toMediaType()))
                    .build()
                OkHttpClient().newCall(request).execute().use { }
            } finally {
                pending.finish()
            }
        }
    }
}
