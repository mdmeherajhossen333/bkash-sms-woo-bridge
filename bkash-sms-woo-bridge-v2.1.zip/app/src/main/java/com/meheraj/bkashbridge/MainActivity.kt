package com.meheraj.bkashbridge

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private val prefsName = "bridge"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val prefs = getSharedPreferences(prefsName, MODE_PRIVATE)
        val endpoint = findViewById<EditText>(R.id.endpoint)
        val token = findViewById<EditText>(R.id.token)
        val status = findViewById<TextView>(R.id.status)

        endpoint.setText(prefs.getString("endpoint", ""))
        token.setText(prefs.getString("token", ""))

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECEIVE_SMS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECEIVE_SMS), 100)
        }

        findViewById<Button>(R.id.save).setOnClickListener {
            prefs.edit()
                .putString("endpoint", endpoint.text.toString().trim())
                .putString("token", token.text.toString().trim())
                .apply()
            status.text = "Saved. Waiting for bKash payment SMS…"
        }
    }
}
